package com.example.midtest

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.*

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val editTextPhone = findViewById<EditText>(R.id.editTextPhone)
        val spinnerB = findViewById<Spinner>(R.id.spinnerB)
        val spinnerS = findViewById<Spinner>(R.id.spinnerS)
        val big = arrayListOf("","0大","1大","2大","3大","4大")
        val small = arrayListOf("","0小","1小","2小","3小","4小")
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item,big)
        val adapter2 = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item,small)
        spinnerB.adapter = adapter
        spinnerS.adapter = adapter2


        val checkBox = findViewById<CheckBox>(R.id.checkBox)
        val checkBox2 = findViewById<CheckBox>(R.id.checkBox2)
        val buttonSend = findViewById<Button>(R.id.buttonSend)

        buttonSend.setOnClickListener{

            // 获取Spinner和CheckBox的选择值
            val phoneNumber = editTextPhone.text.toString()
            val selectedBig = spinnerB.selectedItem.toString()
            val selectedSmall = spinnerS.selectedItem.toString()
            val isChecked1 = checkBox.isChecked
            val isChecked2 = checkBox2.isChecked

            // 创建Intent并将选择值放入
            val secondIntent = Intent(this, MainActivity2::class.java)
            secondIntent.putExtra("phoneNumber", phoneNumber)
            secondIntent.putExtra("bigSelection", selectedBig)
            secondIntent.putExtra("smallSelection", selectedSmall)
            secondIntent.putExtra("checkBox1", isChecked1)
            secondIntent.putExtra("checkBox2", isChecked2)

            startActivity(secondIntent)
        }



    }
}