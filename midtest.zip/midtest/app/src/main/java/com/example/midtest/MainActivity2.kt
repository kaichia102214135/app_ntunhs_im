package com.example.midtest

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView

class MainActivity2 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main2)
        val buttonBack = findViewById<Button>(R.id.buttonBack)

        val phoneNumber = intent.getStringExtra("phoneNumber")
        val bigSelection = intent.getStringExtra("bigSelection")
        val smallSelection = intent.getStringExtra("smallSelection")
        val isChecked1 = intent.getBooleanExtra("checkBox1", false)
        val isChecked2 = intent.getBooleanExtra("checkBox2", false)
        var a = ""
        if (isChecked1 == true && isChecked2 == true){
            a = "需要兒童餐具以及兒童椅"
        }
        if (isChecked1 == true && isChecked2 == false){
            a = "需要兒童餐具不需要兒童椅"
        }
        if (isChecked1 == false && isChecked2 == true){
            a = "不需要兒童餐具需要兒童椅"
        }
        if (isChecked1 == false && isChecked2 == false){
            a = "不需要兒童餐具以及兒童椅"
        }
        // 显示在TextView中
        val textView = findViewById<TextView>(R.id.textView)
        textView.text = "訂位電話:$phoneNumber\n人數 $bigSelection $smallSelection\n $a "





        buttonBack.setOnClickListener{
            var secondIntent = Intent(this,MainActivity::class.java)
            startActivity(secondIntent)
        }
    }
}